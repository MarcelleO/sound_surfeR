## ---- include=FALSE-----------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>",
  root.dir = "D:/BACK-UP'/documents'/UT AUSTIN/Spring 2022/ANT388 (R-coding)/sound_surfer"
  )

## -----------------------------------------------------------------------------
library(soundsurfer)
#data folder contains the wave files used in our example workflow. For a list of files withing the data folder use: 
fileList <- list.files(path = "data", full.names = TRUE)
fileList

## -----------------------------------------------------------------------------
library(tuneR)
beep1 = readWave("../data/3beep1.wav")
#info for beep audio file 
str(beep1)



# determine duration and frequency 
dur = length(beep1)/beep1@samp.rate
dur # seconds
fs = beep1@samp.rate
fs # Hz

# extract signal
snd = beep1@left



## -----------------------------------------------------------------------------
# demean to remove DC offset and clean audio 
#DC offset = mean amplitude displacement from zero
snd = demean(snd)

# plot waveform
plot(snd, type = 'l', xlab = 'Samples', ylab = 'Amplitude')


## -----------------------------------------------------------------------------
# number of points to use for the fft
nfft=1024
# window size (in points)
window=256
# overlap (in points)
overlap=128

## -----------------------------------------------------------------------------
library(signal, warn.conflicts = F, quietly = T) # signal processing functions

library(oce, warn.conflicts = F, quietly = T) # image plotting functions and nice color maps

spec = specgram(x = snd,
                n = nfft,
                Fs = fs,
                window = window,
                overlap = overlap
)
# discard phase information
P = abs(spec$S)
# normalize
P = P/max(P)
# convert to dB
P = 10*log10(P)
# config time axis
t = spec$t
# plot spectrogram
imagep(x = t,
       y = spec$f,
       z = t(P),
       col = oce.colorsViridis,
       ylab = 'Frequency [Hz]',
       xlab = 'Time [s]',
       drawPalette = T,
       decimate = F
)








#info for clap audio file 
str(clap1)

# extract signal
snd = clap1@left

# determine duration and frequency 
dur = length(clap1)/clap1@samp.rate
dur # seconds
fs = beep1@samp.rate
fs # Hz

snd = demean(snd)

# plot waveform
plot(snd, type = 'l', xlab = 'Samples', ylab = 'Amplitude')

# number of points to use for the fft
nfft=1024
# window size (in points)
window=256
# overlap (in points)
overlap=128

# create spectrogram

spec = specgram(x = snd,
                n = nfft,
                Fs = fs,
                window = window,
                overlap = overlap
)


# discard phase information
P = abs(spec$S)
# normalize
P = P/max(P)
# convert to dB
P = 10*log10(P)
# config time axis
t = spec$t
# plot spectrogram
imagep(x = t,
       y = spec$f,
       z = t(P),
       col = oce.colorsViridis,
       ylab = 'Frequency [Hz]',
       xlab = 'Time [s]',
       drawPalette = T,
       decimate = F
)





#info for note audio file 
str(note1)

# extract signal
snd = note1@left

# determine duration and frequency 
dur = length(note1)/note1@samp.rate
dur # seconds
fs = beep1@samp.rate
fs # Hz

snd = demean(snd)

# plot waveform
plot(snd, type = 'l', xlab = 'Samples', ylab = 'Amplitude')

# number of points to use for the fft
nfft=1024
# window size (in points)
window=256
# overlap (in points)
overlap=128


# create spectrogram

spec = specgram(x = snd,
                n = nfft,
                Fs = fs,
                window = window,
                overlap = overlap
)

# discard phase information
P = abs(spec$S)

# normalize
P = P/max(P)

# convert to dB
P = 10*log10(P)

# config time axis
t = spec$t

# plot spectrogram
imagep(x = t,
       y = spec$f,
       z = t(P),
       col = oce.colorsViridis,
       ylab = 'Frequency [Hz]',
       xlab = 'Time [s]',
       drawPalette = T,
       decimate = F
)


## -----------------------------------------------------------------------------
library(monitoR)

viewSpec(beep1, frq.lim=c(2, 6), start.time=0, page.length=4)

## -----------------------------------------------------------------------------
#create binary match point template 1 for beep sound 

  
BTemp_beep1 <- makeBinTemplate("../data/3beep1.wav", frq.lim = c(3, 6), t.lim = c(0, .7), name = "3beep1", amp.cutoff = (-25))

#template 2 for beep sound .
BTemp_beep2 <- makeBinTemplate("../data/3beep2.wav", frq.lim = c(3, 6), t.lim = c(0, .7), name = "3beep2", amp.cutoff = (-25))

#template 1 for clap sound 
BTemp_clap1 <- makeBinTemplate("../data/clap1.wav", frq.lim = c(0.1, 6), t.lim = c(0, .5), name = "clap1", amp.cutoff = (-25))

#template 2 for clap sound 
BTemp_clap2 <- makeBinTemplate("../data/clap2.wav", frq.lim = c(0.1, 6), t.lim = c(0, .5), name = "clap2", amp.cutoff = (-25))

#template 1 for note sound 
BTemp_note1 <- makeBinTemplate("../data/note1.wav", frq.lim = c(0.1, 6), t.lim = c(0, .5), name = "note1", amp.cutoff = (-25))

#template 2 for note sound 
BTemp_note2 <- makeBinTemplate("../data/note1.wav", frq.lim = c(0.1, 6), t.lim = c(0, .5), name = "note2", amp.cutoff = (-25))





#create spectrograph cross correlation template 1 for beep sound 
CTemp_beep1 <- makeCorTemplate("../data/3beep1.wav", frq.lim = c(3, 6), t.lim = c(0, .7), name = "3beep1", amp.cutoff = (-25))

#template 2 for beep sound .
CTemp_beep2 <- makeCorTemplate("../data/3beep2.wav", frq.lim = c(3, 6), t.lim = c(0, .7), name = "3beep2", amp.cutoff = (-25))

#template 1 for clap sound 
CTemp_clap1 <- makeCorTemplate("../data/clap1.wav", frq.lim = c(0.1, 6), t.lim = c(0, .5), name = "clap1", amp.cutoff = (-25))

#template 2 for clap sound 
CTemp_clap2 <- makeCorTemplate("../data/clap2.wav", frq.lim = c(0.1, 6), t.lim = c(0, .5), name = "clap2", amp.cutoff = (-25))

#template 1 for note sound 
CTemp_note1 <- makeCorTemplate("../data/note1.wav", frq.lim = c(0.1, 6), t.lim = c(0, .5), name = "note1", amp.cutoff = (-25))

#template 2 for note sound 
CTemp_note2 <- makeCorTemplate("../data/note2.wav", frq.lim = c(0.1, 6), t.lim = c(0, .5), name = "note2", amp.cutoff = (-25))



## -----------------------------------------------------------------------------
#Create a list with the respective templates you want to use for the analysis

tempbin <- combineBinTemplates(BTemp_beep1, BTemp_beep2, BTemp_clap1, BTemp_clap2) 


tempcor <- combineCorTemplates(CTemp_beep1, CTemp_beep2, CTemp_clap1, CTemp_clap2)

## -----------------------------------------------------------------------------
bma("../data/3beep3.wav", tempbin)

cma("../data/3beep3.wav", tempcor)


